#!/bin/bash

# El script se ejecuta con sudo
# Restablece las politicas por defecto del iptables
iptables -P INPUT ACCEPT
iptables -P OUTPUT ACCEPT
iptables -P FORWARD ACCEPT

iptables -F

iptables -Z


exit 0
