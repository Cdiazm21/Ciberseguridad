#!/bin/bash

# Borramos las reglas existentes:
iptables -F
iptables -Z
iptables -t nat -F

# Establecemos políticas restrictivas (DROP) por defecto.
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

# Permitimos el tráfico de loopback en la máquina Debian.
iptables -A INPUT -i lo -j ACCEPT
iptables -A OUTPUT -o lo -j ACCEPT

# La máquina Debian podrá realizar conexiones SSH.
# SSH saliente:
iptables -A OUTPUT -p tcp --dport 22 -j ACCEPT

# La máquina Debian es un servidor SSH.
# SSH entrante:
iptables -A INPUT -p tcp --dport 22 -s 10.0.3.13 -j ACCEPT

# La máquina Debian tendrá permitido solo el tráfico ICMP saliente.
iptables -A OUTPUT -p icmp -j ACCEPT

# La máquina Debian podrá usar como cliente: DNS, HTTP y HTTPS.
# DNS saliente:
iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
iptables -A INPUT -p udp --sport 53 -m state --state ESTABLISHED,RELATED -j ACCEPT
# HTTP y HTTPS salientes:
iptables -A OUTPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --sport 80 -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A OUTPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -p tcp --sport 443 -m state --state ESTABLISHED,RELATED -j ACCEPT

# Permitimos cualquier otro tráfico de salida necesario:
iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Permitimos cualquier otro tráfico de entrada necesario:
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

exit 0
