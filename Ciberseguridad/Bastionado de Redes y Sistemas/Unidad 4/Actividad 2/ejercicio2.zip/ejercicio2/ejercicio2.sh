#!/bin/bash

# Borramos las reglas existentes:
iptables -F
iptables -Z
iptables -t nat -F

# Establecemos políticas restrictivas (DROP) por defecto.
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

# Permitimos el tráfico de loopback en la máquina Debian.
iptables -A INPUT -i lo -j ACCEPT
iptables -A OUTPUT -o lo -j ACCEPT

# La máquina Debian podrá realizar conexiones SSH.
# SSH saliente:
iptables -A OUTPUT -p tcp --dport 22 -j ACCEPT

# La máquina Debian es un servidor SSH.
# SSH entrante:
iptables -A INPUT -p tcp --dport 22 -s 1 -j ACCEPT


# Accesibilidad desde la LAN

iptables -A INPUT -i eth2 -s 10.0.0.1/24 -j ACCEPT


# Accesibilidad desde las direcciones 8.8.8.8 y 8.8.4.4

iptables -A OUTPUT -s 8.8.8.8 -j ACCEPT
iptables -A OUTPUT -s 8.8.4.4 -j ACCEPT

# El tráfico ICMP estará permitido tanto de entrada como de salida para todas las interfaces
iptables -A INPUT -p icmp -j ACCEPT

# Se permiten las conexiones SSH hacia los servidores DMZ
# La red del servidor que se encuentra en el DMZ es 172.16.0.0/24

iptables -A INPUT -p tcp --dport 22 -s 172.16.0.0/24 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 22 -s 172.16.0.0/24 -j ACCEPT


# La máquina Debian podrá usar como cliente: DNS, HTTP y HTTPS.
# DNS:
iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
iptables -A INPUT -p udp --sport 53 -m state --state ESTABLISHED,RELATED -j ACCEPT

# HTTP:
iptables -A OUTPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --sport 80 -m state --state ESTABLISHED,RELATED -j ACCEPT

# HTTPS:
iptables -A OUTPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -p tcp --sport 443 -m state --state ESTABLISHED,RELATED -j ACCEPT

####################
####### DMZ ########
####################

# La red DMZ tiene  acceso a DNS, HTTP y HTTPS

# DNS:
iptables -A FORWARD -s 172.16.0.0/24 -p udp --dport 53 -j ACCEPT
iptables -A FORWARD -d 172.16.0.0/24 -p udp --sport 53 -m state --state ESTABLISHED -j ACCEPT

# HTTP:

iptables -A FORWARD -s 172.16.0.0/24 -p udp --dport 80 -j ACCEPT
iptables -A FORWARD -d 172.16.0.0/24 -p udp --sport 80 -m state --state ESTABLISHED -j ACCEPT

# HTTPS:

iptables -A FORWARD -s 172.16.0.0/24 -p udp --dport 443 -j ACCEPT
iptables -A FORWARD -d 172.16.0.0/24 -p udp --sport 443 -m state --state ESTABLISHED -j ACCEPT


# La red DMZ acepta el trafico ICMP de tipo 0,3,8 y 11
# Permite ICMP tipo 0 (Echo Reply)
iptables -A FORWARD -s 172.16.0.0/24 -p icmp --icmp-type echo-reply -j ACCEPT

# Permite ICMP tipo 3 (Destination Unreachable)
iptables -A FORWARD -s 172.16.0.0/24 -p icmp --icmp-type destination-unreacheable -j ACCEPT

# Permite ICMP tipo 8 (Echo Request)
iptables -A FORWARD -s 172.16.0.0/24 -p icmp --icmp-type echo-request -j ACCEPT

# Permite ICMP tipo 11 (Time Exceeded)
iptables -A FORWARD -s 172.16.0.0/24 -p icmp --icmp-type time-exceeded -j ACCEPT


# La IP 172.16.0.2 es servidor web
# Ahora añadimoslos servicios  HTTP y HTTPS

iptables -A FORWARD -d 172.16.0.2 -i eth1 -p tcp --dport 80 -j ACCEPT
iptables -A FORWARD -d 172.16.0.2 -i eth1 -p tcp --dport 443 -j ACCEPT

# Servicios del Servidor de Correos(172.16.0.3)

iptables -A FORWARD -d 172.16.0.3 -i eth1 -p tcp --dport 25 -j ACCEPT
iptables -A FORWARD -d 172.16.0.3 -i eth1 -p tcp --dport 2525 -j ACCEPT
iptables -A FORWARD -d 172.16.0.3 -i eth1 -p tcp --dport 587 -j ACCEPT
iptables -A FORWARD -d 172.16.0.3 -i eth1 -p tcp --dport 465 -j ACCEPT
iptables -A FORWARD -d 172.16.0.3 -i eth1 -p tcp --dport 110 -j ACCEPT
iptables -A FORWARD -d 172.16.0.3 -i eth1 -p tcp --dport 995 -j ACCEPT
iptables -A FORWARD -d 172.16.0.3 -i eth1 -p tcp --dport 220 -j ACCEPT
iptables -A FORWARD -d 172.16.0.3 -i eth1 -p tcp --dport 993 -j ACCEPT

####################################
########### LAN ####################
####################################

# Se permiten consultas DNS
iptables -A FORWARD -i eth2 -o eth0 -p udp --dport 53 -j ACCEPT


# La LAN acepta el trafico ICMP de tipo 0,3,8 y 11
# Permite ICMP tipo 0 (Echo Reply)
iptables -A FORWARD -s 10.0.0.1/24 -p icmp --icmp-type echo-reply -j ACCEPT

# Permite ICMP tipo 3 (Destination Unreachable)
iptables -A FORWARD -s 10.0.0.1/24 -p icmp --icmp-type destination-unreacheable -j ACCEPT

# Permite ICMP tipo 8 (Echo Request)
iptables -A FORWARD -s 10.0.0.1/24 -p icmp --icmp-type echo-request -j ACCEPT

# Permite ICMP tipo 11 (Time Exceeded)
iptables -A FORWARD -s 10.0.0.1/24 -p icmp --icmp-type time-exceeded -j ACCEPT

# Se permite tráfico HTTP y HTTPS
iptables -A FORWARD -i eth2 -o eth0 -p tcp --dport 80 -j ACCEPT
iptables -A FORWARD -i eth2 -o eth0 -p tcp --dport 443 -j ACCEPT

# La máquina es servidor HTTP
iptables -A FORWARD -d 10.0.0.2 -i eth2 -p tcp --dport 80 -j ACCEPT


########################
######### DNAT #########
########################

# Abrimos puertos con DNAT (tabla nat):
iptables -t nat -A PREROUTING -p tcp --dport 25 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 2525 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 587 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 465 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 220 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 993 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 955 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 110 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 53 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 443 -j DNAT --to-destination $IPDinamica
iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination $IPDinamica

# SNAT para las redes internas
# Para redes internas - SNAT (tabla nat):

iptables -t nat -A POSTROUTING -p tcp -s 10.0.0.0 -j SNAT  --to-destination $IPDinamica
iptables -t nat -A POSTROUTING -p tcp -s 172.16.0.0 -j SNAT --to-destination $IPDinamica










