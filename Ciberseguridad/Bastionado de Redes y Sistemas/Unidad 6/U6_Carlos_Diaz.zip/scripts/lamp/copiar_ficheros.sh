#!/bin/bash

# Función para copiar archivos según la selección del usuario
copiar_archivos() {
# El tipo de archivos a copiar: apache, php o mysql
    tipo_archivos=$1  
# Ruta de destino
    destino=$2        

    case $tipo_archivos in
        apache)
            ruta_archivos="/home/cdiaz/scripts/lamp/ficheros_apache_originales/"
            ;;
        php)
            ruta_archivos="/home/cdiaz/scripts/lamp/ficheros_php_originales/"
            ;;
        mysql)
            ruta_archivos="/home/cdiaz/scripts/lamp/ficheros_mysql_oiginales/"
            ;;
        *)
            echo "Tipo de archivos no válido."
            exit 1
            ;;
    esac

    # Copiar archivos de la ruta correspondiente al destino
    cp -r "$ruta_archivos"/* "$destino"
    echo "Archivos de $tipo_archivos copiados con éxito."
}

# Solicitar al usuario el tipo de archivos a copiar
read -p "Qué tipo de archivos desea copiar? (apache/php/mysql): " tipo

# Solicitar al usuario la ruta de destino
read -p "Ingrese la ruta del directorio de destino: " destino

# Llamar a la función copiar_archivos con la selección del usuario y la ruta de destino
copiar_archivos $tipo $destino


exit 0