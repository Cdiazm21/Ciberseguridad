#!/bin/bash

########## Variables ##########

# Directorio de origen
origen="$HOME/scripts/lamp/ficheros_php_originales"

# Directorio de destino
destino="$HOME/scripts/lamp/fichero_php_sandbox/"

# Creamos la variable de las funciones que deshabilitamos
info="phpinfo, system, exec, shell_exec, ini_set, dl, eval"

# Fichero que queremos modificar
ruta_php_ini="$HOME/scripts/lamp/fichero_php_sandbox/php.ini"

# Función para registrar los cambios en el informe
registrar_cambios() {
    echo "=== Informe de Cambios ==="
    echo "Fecha y hora: $(date)"
    echo "Usuario: $USER"
    echo "Descripcion de los cambios realizados:"
    echo "- Archivo copiado: $archivo copiado como php.ini en $destino"
    echo "- Cambios en php.ini:"
    echo "  * expose_php: Cambiado de On a Off"
    echo "  * display_errors: Cambiado de On a Off"
    echo "  * open_basedir: Editado para permitir /var/www"
    echo "  * disable_functions: Deshabilitadas las funciones: $info"
    echo "  * allow_url_fopen: Cambiado de On a Off"
    echo "  * allow_url_include: Cambiado de On a Off"
}

# Mostrar opciones disponibles
echo "Seleccione un archivo:"
echo "1. php5_5.txt"
echo "2. php5_6.txt"
echo "3. php7_0.txt"
echo "4. php7_1.txt"
echo "5. php7_2.txt"

# Damos la opción de seleccionar la version del archivo que queramos
read -p "Elige el número correspondiente al archivo: " opcion

# Validar la opción seleccionada
case $opcion in
    1) archivo="php5_5.txt";;
    2) archivo="php5_6.txt";;
    3) archivo="php7_0.txt";;
    4) archivo="php7_1.txt";;
    5) archivo="php7_2.txt";;
    *) echo "Opción no válida"; exit 1;;
esac

# Copiar el archivo seleccionado al directorio de destino con el nombre php.ini
cp "$origen/$archivo" "$destino/php.ini"

echo "El archivo $archivo ha sido copiado como php.ini en $destino"


# uso del comando sed
# 1 Empezamos por expose_php
sed -i "s/expose_php = On/expose_php = Off/g" $ruta_php_ini

# 2 editamos el display_errors
sed -i "s/display_errors = On/display_errors = Off/g" $ruta_php_ini

# 3 editamos open_basedir
sed -i "s/;open_basedir =/open_basedir = \/var\/www/g" "$ruta_php_ini"

# 4 editamos disable_functions
# las funciones desabilidatas  son  phpinfo, system, exec, shell_exec, ini_set, dl, eval
sed -i "s/disable_functions\s*.*/disable_functions = $info/g" $ruta_php_ini

# 5 editamos Remote File Inclusion (RFI)
# para ello editamos los parámetros allow_url_fopen y allow_url_include
sed -i "s/allow_url_fopen\s*.*/allow_url_fopen = Off/g" $ruta_php_ini
sed -i "s/allow_url_include\s*.*/allow_url_include = Off/g" $ruta_php_ini

# Registra los cambios en el informe
registrar_cambios

exit 0
