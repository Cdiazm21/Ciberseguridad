#!/bin/bash

############## variables ############

# Directorio de origen
origen="$HOME/scripts/lamp/ficheros_apache_originales"

# Directorio de destino
destino="$HOME/scripts/lamp/ficheros_apache_sandbox"

# El fichero apache2.conf
ruta_fichero_apache2="$HOME/scripts/lamp/ficheros_apache_sandbox/apache2.conf"

# El fichero security.conf
ruta_fichero_security="$HOME/scripts/lamp/ficheros_apache_sandbox/security.conf"

# Función para registrar los cambios en el informe
registrar_cambios() {
    echo "=== Informe de Cambios ==="
    echo "Fecha y hora: $(date)"
    echo "Usuario: $USER"
    echo "Descripcion de los cambios realizados:"
    echo "- Archivos copiados y enviados:"
    echo "  * apache2.conf y security.conf copiados y enviados a $destino"
    echo "- Cambios en apache2.conf:"
    echo "  * Usuario y grupo cambiados a www-data"
    echo "  * Modulos autoindex y cgi deshabilitados"
    echo "- Cambios en security.conf:"
    echo "  * Parametro ServerTokens cambiado a ProductOnly"
    echo "  * Parametro ServerSignature cambiado a Off"
}

# Mostrar advertencia y solicitar confirmación
read -p "¿Estás seguro de que deseas copiar y enviar los archivos apache2.conf y security.conf? (S/n) " respuesta

# Convertir la respuesta a minúsculas para manejar 'S' y 's'
respuesta=$(echo "$respuesta" | tr '[:upper:]' '[:lower:]')

# Verificar la respuesta
if [[ "$respuesta" == "s" ]]; then
    # Copiar y enviar los archivos
    cp "$origen/apache2.conf" "$destino/apache2.conf"
    cp "$origen/security.conf" "$destino/security.conf"

    echo "Los archivos apache2.conf y security.conf han sido copiados y enviados a $destino"
else
    echo "Operación cancelada."
fi

# Queremos editar el fichero de ocnfiguración de apache2 (apache2.conf)
# Los parametros que queremos editar son:
# 1. Queremos ponerle como usuario y grupo www-data

sed -i "s/^User\s.*/User www-data/g" $ruta_fichero_apache2
sed -i "s/^Group\s.*/Group www-data/g" $ruta_fichero_apache2

# 2. deshabilitamos los modulos innecesarios.
# Queremos quitar los modulos autoindex y cgi
a2dismod autoindex
a2dismod cgi
# Ahora tendríamos que reiniciar el servicio apache
systemctl restart apache2.service

# 3. Ahora editamos el fichero security.conf
# Queremos editar el parametro ServerTokens OS y ServerSignature On

sed -i "s/^ServerTokens OS/ServerTokens ProductOnly/g" $ruta_fichero_security
sed -i "s/ServerSignature On/ServerSignature Off/g" $ruta_fichero_security

# Registra los cambios en el informe
registrar_cambios

exit 0