#!/bin/bash

########## variables ############

# Definimos credenciales de base de datos
DB_NAME="nombre_basedatos"
DB_USER="carlos"
DB_PASS="carlospassword"
ROOT_PASS="contraseña_root"

# Directorio de origen
origen="$HOME/scripts/lamp/ficheros_mysql_oiginales"

# Directorio de destino
destino="$HOME/scripts/lamp/ficheros_mysql_sandbox"

# Seleccionamos las variables del fichero
ruta_fichero_mysql="$HOME/scripts/lamp/ficheros_mysql_sandbox/mysqld.conf"


# Mostrar advertencia y solicitar confirmación
read -p "¿Estás seguro de que deseas copiar y enviar el archivo mysqld.conf? (S/n) " respuesta

# Convertir la respuesta a minúsculas para manejar 'S' y 's'
respuesta=$(echo "$respuesta" | tr '[:upper:]' '[:lower:]')

# Verificar la respuesta
if [[ "$respuesta" == "s" ]]; then
    # Copiar y enviar los archivos
    cp "$origen/mysqld.conf" "$destino/mysqld.conf"
    
    echo "El archivo mysqld.conf ha sido copiado y enviado a $destino"
else
    echo "Operación cancelada."
    exit 1
fi

# Función para registrar los cambios en el informe
registrar_cambios() {
    echo "=== Informe de Cambios ==="
    echo "Fecha y hora: $(date)"
    echo "Usuario: $USER"
    echo "Descripcion de los cambios realizados:"
    echo "- Cambios en el archivo mysqld.conf:"
    echo "  * Parámetro bin-address cambiado a 127.0.0.1"
    echo "  * Parámetro local-infile cambiado a 0 (si existía)"
    echo "  * Parámetro secure-file-priv cambiado a /dev/null (si existía)"
    echo "- Usuarios anónimos eliminados"
    echo "- Usuario root renombrado a carlos"
    echo "- Contraseña del usuario carlos establecida"
    echo "- Base de datos de prueba eliminada"
    echo "- Base de datos, usuario y privilegios creados"
}

# Vamos a configurar el archivo mysqld.conf

# 1. Ahora queremos cambiar el parametro bin-address
sed -i "s/bin-address\s*.*/bin-address = 127.0.0.1/g" "$ruta_fichero_mysql"

# 2. Evitamos el acceso al sistema desde el propio mysql
# Estos parametros no estan en todos los archivos, oseq que lo más probable esque no esten. Pero lo añadimos los cambios en caso de que estuvieran
sed -i "s/local-infile\s*.*/local-infile = 0/g" "$ruta_fichero_mysql"
sed -i "s/secure-file-priv\s*.*/secure-file-priv =\/dev\/null/g" "$ruta_fichero_mysql"

# 3. 4. y 5.
# Para hacer esta parte vamos a querer acceder a la consola de comandos de mysql.

# Buscamos los usuarios anónimos y los eliminamos
mysql -u root -p"$ROOT_PASS" -e "DELETE FROM mysql.user WHERE User='';" -e "FLUSH PRIVILEGES;"

# Renombramos el usuario root a carlos
mysql -u root -p"$ROOT_PASS" -e "RENAME USER 'root'@'localhost' TO 'carlos'@'localhost';"

# Establecemos la contraseña del usuario carlos
mysql -u carlos -p"$ROOT_PASS" -e "ALTER USER 'carlos'@'localhost' IDENTIFIED BY '$ROOT_PASS';"

# Eliminamos la base de dato de test
mysql -u carlos -p"$ROOT_PASS" -e "DROP DATABASE IF EXISTS test;" -e "DELETE FROM mysql.db WHERE Db='test' OR Db='test\_%';" -e "FLUSH PRIVILEGES;"

# Registra los cambios en el informe
registrar_cambios

exit 0
